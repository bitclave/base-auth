import json
from collections import OrderedDict
from typing import Any, Dict, Iterable

import requests

from .encryption import encrypt_message
from .hashes import keccak256
from .key_derivation import KeyPair, PublicKey, derive_keypair, pbkdf2
from .signatures import Signer

__all__ = ['BASEClient', 'BASENodeRequest', 'BASENodeSignedResponse']


class BASENodeRequest:

    def __init__(self, api_url: str, data: dict, keypair: KeyPair) -> None:
        self.api_url = api_url
        self.data = data
        self.keypair = keypair
        self.signer = Signer(self.keypair.private_key)

    def send(self) -> requests.Response:
        return requests.post(
            self.api_url,
            json={
                'data': self.data,
                'pk': self.keypair.public_key.hex_compressed,
                'sig': self.signer.sign(self.data),
            })


class BASENodeSignedResponse:

    def __init__(self, response: requests.Response, verification_message: str,
                 keypair: KeyPair) -> None:
        self.response = response
        self.verification_message = verification_message
        self.keypair = keypair
        self.signer = Signer(self.keypair.private_key)

    @property
    def ok(self) -> bool:
        return self.response.ok

    @property
    def status_code(self) -> int:
        return self.response.status_code

    def json(self) -> dict:
        response_json = self.response.json()

        if self.response.ok:
            response_json['message'] = self.verification_message
            response_json['sig'] = self.signer.sign_raw(
                self.verification_message)

        return response_json


class BASEClient:
    SIGN_UP = 'registration'
    SIGN_IN = 'exist'
    GRANT_ACCESS_FOR_CLIENT = 'data/grant/request/'
    DATA_REQUEST_STATE_UNDEFINED = 'UNDEFINED'

    def __init__(self, base_node_url: str) -> None:
        self.base_node_url = base_node_url

        if not self.base_node_url.endswith('/'):
            self.base_node_url += '/'

    def api_url(self, endpoint: str) -> str:
        return f'{self.base_node_url}{endpoint}'

    def create_account(self, mnemonic: str,
                       verification_message: str) -> BASENodeSignedResponse:
        response = self.exist(mnemonic, verification_message)

        if response.status_code == 200:
            return response

        return self.registration(mnemonic, verification_message)

    def exist(self, mnemonic: str,
              verification_message: str) -> BASENodeSignedResponse:
        keypair = derive_keypair(mnemonic)
        request = BASENodeRequest(
            self.api_url(self.SIGN_IN),
            {'publicKey': keypair.public_key.hex_compressed}, keypair)
        return BASENodeSignedResponse(request.send(), verification_message,
                                      keypair)

    def registration(self, mnemonic: str,
                     verification_message: str) -> BASENodeSignedResponse:
        keypair = derive_keypair(mnemonic)
        request = BASENodeRequest(
            self.api_url(self.SIGN_UP),
            {'publicKey': keypair.public_key.hex_compressed}, keypair)
        return BASENodeSignedResponse(request.send(), verification_message,
                                      keypair)

    def grant_access_for_client(self, mnemonic: str, to_public_key: str,
                                fields: Iterable[str]) -> requests.Response:
        keypair = derive_keypair(mnemonic)
        encrypted_response = _encrypt_fields(
            keypair.private_key,
            PublicKey.from_hex_compressed(to_public_key), fields)

        # TODO Порядок влияет на подпись, надо ключи сортировать.
        request_data: Dict[str, Any] = OrderedDict()
        request_data['id'] = 0
        request_data['fromPk'] = to_public_key
        request_data['toPk'] = keypair.public_key.hex_compressed
        request_data['requestData'] = ''
        request_data['responseData'] = encrypted_response
        request_data['state'] = self.DATA_REQUEST_STATE_UNDEFINED

        request = BASENodeRequest(
            self.api_url(self.GRANT_ACCESS_FOR_CLIENT), request_data, keypair)
        return request.send()


def _generate_password_for_field(private_key: str, field: str) -> str:
    return pbkdf2(keccak256(private_key) + field.lower(), 384)


def _encrypt_fields(from_private_key: str, to_public_key: PublicKey,
                    fields: Iterable[str]):
    password_by_field: Dict[str, str] = OrderedDict()

    for field in fields:
        password_by_field['field'] = _generate_password_for_field(
            from_private_key, field)

    return encrypt_message(from_private_key, to_public_key,
                           json.dumps(password_by_field))
