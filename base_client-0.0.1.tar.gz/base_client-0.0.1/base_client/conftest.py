import random
import string
from typing import Any, Optional

import pytest

from .client import BASEClient


@pytest.fixture
def generate_random_string():

    def _generate_random_string(length):
        return ''.join(random.sample(string.ascii_letters, length))

    return _generate_random_string


class ResponseMock:
    STATUS_CODES_OK = {200, 201}
    STATUS_CODES_NOT_OK = {404, 409}

    def __init__(self, status_code: int, json: Optional[Any] = None) -> None:
        self.status_code = status_code
        self._json = json

    @property
    def ok(self):
        if self.status_code in self.STATUS_CODES_OK:
            return True

        if self.status_code in self.STATUS_CODES_NOT_OK:
            return False

        raise NotImplementedError(f'Status code: {self.status_code}')

    def json(self):
        return self._json


class BASENodeServerMock:

    def __init__(self):
        self.public_keys = set()

    def post(self, url: str, json: dict) -> ResponseMock:
        if url.endswith('/v1/exist'):
            return self.v1_exist(json)

        if url.endswith('/v1/registration'):
            return self.v1_registration(json)

        if url.endswith('/v1/data/grant/request/'):
            return self.v1_grant_access_for_client(json)

        raise NotImplementedError(f'Handler for the {url} is not implemented')

    def v1_exist(self, json: dict) -> ResponseMock:
        if json['data']['publicKey'] not in self.public_keys:
            return ResponseMock(404, {
                'timestamp': 1524242923790,
                'status': 404,
                'exception': '...',
                'message': '...',
                'error': '...',
                'path': '...'
            })

        return ResponseMock(200, {'publicKey': json['data']['publicKey']})

    def v1_registration(self, json: dict) -> ResponseMock:
        if json['data']['publicKey'] in self.public_keys:
            return ResponseMock(409, {
                'timestamp': 1524242579101,
                'status': 409,
                'exception': '...',
                'message': '...',
                'error': '...',
                'path': '...'
            })

        self.public_keys.add(json['data']['publicKey'])
        return ResponseMock(201, {'publicKey': json['data']['publicKey']})

    def v1_grant_access_for_client(self, json: dict) -> ResponseMock:
        if json['data']['toPk'] not in self.public_keys:
            return ResponseMock(404, {
                'error': '...',
                'exception': '...',
                'message': '...',
                'path': '...',
                'status': 404,
                'timestamp': 1524505324862
            })

        return ResponseMock(201, random.randint(1, 100000))


@pytest.fixture
def base_client():
    return BASEClient('https://base2-bitclva-com.herokuapp.com/v1/')


@pytest.fixture
def base_node_server(monkeypatch):
    base_node = BASENodeServerMock()
    monkeypatch.setattr('requests.post', base_node.post)
