import json
import os.path

import pytest

from .key_derivation import (
    PublicKey,
    derive_keypair,
    derive_private_key,
    derive_public_key,
    pbkdf2
)


@pytest.fixture
def payload():
    test_payload_path = os.path.join(
        os.path.dirname(__file__), 'key_derivation_test.json')
    with open(test_payload_path) as fh:
        return json.load(fh)


@pytest.mark.parametrize('password, key_size, expected_key', [
    (
        'password',
        256,
        '225085773a265bb530ecd5752a042db65300a2ecc5802e0fca3f56fa57d4aa9f',
    ),
    (
        'mnemonic',
        256,
        '39b2541156b603bf29ae2d2828821f374da82bc3c67eee5bb7bdcd926dfe0d35',
    ),
])
def test_pbkdf2(password: str, key_size: int, expected_key: str) -> None:
    assert pbkdf2(password, key_size) == expected_key


def test_derive_private_key(payload) -> None:
    for item in payload['derive_keypair']:
        mnemonic = item['mnemonic']
        expected_private_key = item['private_key']

        assert len(expected_private_key) == 64
        assert derive_private_key(mnemonic) == expected_private_key


def test_derive_public_key(payload) -> None:
    for item in payload['derive_keypair']:
        mnemonic = item['mnemonic']
        expected_public_key = item['public_key']
        assert derive_public_key(
            derive_private_key(mnemonic)).hex_compressed == expected_public_key


def test_compressed_to_uncompressed(payload) -> None:
    for item in payload['derive_keypair']:
        public_key = item['public_key']
        key = PublicKey.from_hex_compressed(public_key)
        assert key.hex_compressed == public_key


def test_derive_keypair(payload) -> None:
    for item in payload['derive_keypair']:
        mnemonic = item['mnemonic']
        expected_public_key = item['public_key']
        expected_private_key = item['private_key']

        public_key, private_key = derive_keypair(mnemonic)
        assert public_key.hex_compressed == expected_public_key
        assert private_key == expected_private_key
