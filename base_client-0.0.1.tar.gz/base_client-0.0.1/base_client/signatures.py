import binascii
import json

from bitcoin.signmessage import (
    BitcoinMessage,
    P2PKHBitcoinAddress,
    SignMessage,
    VerifyMessage
)
from bitcoin.wallet import CBitcoinSecret

from .key_derivation import PublicKey

__all__ = ['Signer', 'Verifier']


class Signer:

    def __init__(self, private_key: str) -> None:
        if len(private_key) != 64:
            raise ValueError('Invalid private key format')

        self.private_key = private_key

    def sign(self, data: dict) -> str:
        return self.sign_raw(_serialize_data(data))

    def sign_raw(self, message: str) -> str:
        secret = CBitcoinSecret.from_secret_bytes(
            binascii.unhexlify(self.private_key))
        message = BitcoinMessage(message)
        signature: bytes = SignMessage(secret, message)

        return signature.decode('utf-8')


class Verifier:

    def __init__(self, public_key: PublicKey) -> None:
        if len(public_key.hex_compressed) != 66:
            raise ValueError('Invalid public key format')

        self.public_key = public_key

    def verify(self, data: dict, sig: str) -> bool:
        return self.verify_raw(_serialize_data(data), sig)

    def verify_raw(self, message: str, sig: str) -> bool:
        address = P2PKHBitcoinAddress.from_pubkey(
            binascii.unhexlify(self.public_key.hex_compressed))
        message = BitcoinMessage(message)
        return VerifyMessage(address, message, sig)


def _serialize_data(data: dict) -> str:
    return json.dumps(data, separators=(',', ':'))
