from Crypto.Hash import SHA3_256, SHA256

__all__ = ['sha256', 'keccak256']


def sha256(string: str) -> str:
    return SHA256.new(string.encode('utf-8')).hexdigest()


def keccak256(string: str) -> str:
    return SHA3_256.new(string.encode('utf-8')).hexdigest()
