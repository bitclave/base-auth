import pytest

from .hashes import sha256


@pytest.mark.parametrize('value, expected_hash', [
    (
        '36932c0020b68673b1ab4db2ca20cd140e6ee561c66960e1059186ef56058f6',
        'c3e8001c52cad2d9173df6245c3ea8d0a5f8989cbcf44ad473fc3b3adaa995e8',
    ),
])
def test_sha256(value: str, expected_hash: str) -> None:
    assert sha256(value) == expected_hash
