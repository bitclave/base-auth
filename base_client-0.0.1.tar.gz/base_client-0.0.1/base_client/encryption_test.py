import random
import string

from .encryption import decrypt_message, encrypt_message
from .key_derivation import derive_keypair


def test_encrypt_decrypt() -> None:
    sender_mnemonic = ''.join(random.sample(string.ascii_letters, 16))
    sender_keypair = derive_keypair(sender_mnemonic)

    recipient_mnemonic = ''.join(random.sample(string.ascii_letters, 16))
    recipient_keypair = derive_keypair(recipient_mnemonic)

    message = 'message'
    ciphertext = encrypt_message(sender_keypair.private_key,
                                 recipient_keypair.public_key, message)
    plaintext = decrypt_message(recipient_keypair.private_key, ciphertext)

    assert plaintext == message
