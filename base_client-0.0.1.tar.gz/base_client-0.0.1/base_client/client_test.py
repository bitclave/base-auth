from typing import Callable

import pytest

from .client import BASEClient
from .key_derivation import derive_keypair


@pytest.mark.usefixtures('base_node_server')
def test_exist(generate_random_string: Callable,
               base_client: BASEClient) -> None:
    mnemonic = generate_random_string(16)
    message = generate_random_string(16)
    response = base_client.exist(mnemonic, message)
    assert response.status_code == 404
    assert set(response.json().keys()) == {
        'timestamp',
        'status',
        'exception',
        'message',
        'error',
        'path',
    }

    response = base_client.registration(mnemonic, message)
    assert response.status_code == 201, response.json()

    response = base_client.exist(mnemonic, message)
    assert response.status_code == 200
    assert set(response.json().keys()) == {'message', 'publicKey', 'sig'}


@pytest.mark.usefixtures('base_node_server')
def test_registration(generate_random_string: Callable,
                      base_client: BASEClient) -> None:
    mnemonic = generate_random_string(16)
    message = generate_random_string(16)
    response = base_client.registration(mnemonic, message)

    assert response.status_code == 201, response.json()
    assert set(response.json().keys()) == {'message', 'publicKey', 'sig'}

    response = base_client.registration(mnemonic, message)

    assert response.status_code == 409
    assert set(response.json().keys()) == {
        'timestamp',
        'status',
        'exception',
        'message',
        'error',
        'path',
    }


@pytest.mark.usefixtures('base_node_server')
def test_grant_access_for_client(generate_random_string: Callable,
                                 base_client: BASEClient) -> None:
    data_reader_mnemonic = generate_random_string(16)
    data_reader_keypair = derive_keypair(data_reader_mnemonic)
    data_owner_mnemonic = generate_random_string(16)

    response0 = base_client.registration(data_owner_mnemonic, 'message')
    assert response0.status_code == 201, response0.json()

    fields = [generate_random_string(10) for _ in range(3)]
    response1 = base_client.grant_access_for_client(
        data_owner_mnemonic,
        data_reader_keypair.public_key.hex_compressed,
        fields,
    )

    assert response1.status_code == 201, response1.json()
    assert isinstance(response1.json(), int)
