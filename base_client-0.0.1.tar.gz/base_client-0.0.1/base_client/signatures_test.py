import random
import string

from .key_derivation import derive_keypair
from .signatures import Signer, Verifier


def test_signer() -> None:
    mnemonic = ''.join(random.sample(string.ascii_letters, 16))
    keypair = derive_keypair(mnemonic)
    signer = Signer(keypair.private_key)
    sig = signer.sign({'publicKey': keypair.public_key})

    assert len(sig) == 88


def test_verifier() -> None:
    mnemonic = ''.join(random.sample(string.ascii_letters, 16))
    keypair = derive_keypair(mnemonic)
    signer = Signer(keypair.private_key)
    verifier = Verifier(keypair.public_key)
    data = {'publicKey': keypair.public_key}
    sig = signer.sign(data)

    assert verifier.verify(data, sig)
