import binascii
from base64 import b64decode, b64encode

import pyelliptic

from .key_derivation import PublicKey, derive_public_key
from .settings import PYELLIPTIC_CURVE

__all__ = [
    'decrypt_message',
    'encrypt_message',
]


def encrypt_message(from_private_key: str, to_public_key: PublicKey,
                    message: str) -> str:
    from_public_key = derive_public_key(from_private_key)
    sender = pyelliptic.ECC(
        curve=PYELLIPTIC_CURVE,
        pubkey=binascii.unhexlify(from_public_key.hex_uncompressed),
        privkey=binascii.unhexlify(from_private_key))
    recipient = pyelliptic.ECC(
        curve=PYELLIPTIC_CURVE,
        pubkey=binascii.unhexlify(to_public_key.hex_uncompressed))

    ciphertext = sender.encrypt(message, recipient.get_pubkey())
    return b64encode(ciphertext).decode('utf-8')


def decrypt_message(to_private_key: str, ciphertext: str) -> str:
    to_public_key = derive_public_key(to_private_key)
    recipient = pyelliptic.ECC(
        curve=PYELLIPTIC_CURVE,
        pubkey=binascii.unhexlify(to_public_key.hex_uncompressed),
        privkey=binascii.unhexlify(to_private_key))
    return recipient.decrypt(b64decode(ciphertext)).decode('utf-8')
