import binascii
from typing import NamedTuple

from Crypto.Hash import SHA384
from Crypto.Protocol.KDF import PBKDF2

from .hashes import sha256
from .settings import FASTECDSA_CURVE, SECP256K1_P

__all__ = [
    'KeyPair',
    'PublicKey',
    'derive_keypair',
    'derive_private_key',
    'derive_public_key',
    'pbkdf2',
]


class PublicKey(NamedTuple('PublicKey', [('x', int), ('y', int)])):
    PREFIX_Y_EVEN = '02'
    PREFIX_Y_ODD = '03'
    PREFIX_UNCOMPRESSED = '04'

    @classmethod
    def from_hex_compressed(cls, public_key: str) -> 'PublicKey':
        # https://stackoverflow.com/questions/43629265/deriving-an-ecdsa-uncompressed-public-key-from-a-compressed-one/43654055
        prime = int(SECP256K1_P, 16)
        point_x_hex = public_key[2:66]
        point_x = int(point_x_hex, 16)
        prefix = public_key[0:2]

        point_y_square = (pow(point_x, 3, prime) + 7) % prime
        point_y_square_square_root = pow(point_y_square, (prime + 1) // 4,
                                         prime)

        if prefix == cls.PREFIX_Y_EVEN and point_y_square_square_root & 1:
            point_y = (-point_y_square_square_root) % prime
        elif prefix == cls.PREFIX_Y_ODD and not point_y_square_square_root & 1:
            point_y = (-point_y_square_square_root) % prime
        else:
            point_y = point_y_square_square_root

        return cls(point_x, point_y)

    @property
    def hex_compressed(self):
        point_x_hex = hex(self.x)
        point_x_hex = point_x_hex[2:].zfill(64)

        if self.y % 2 == 0:
            return self.PREFIX_Y_EVEN + point_x_hex

        return self.PREFIX_Y_ODD + point_x_hex

    @property
    def hex_uncompressed(self):
        point_x_hex = hex(self.x)[2:].zfill(64)
        point_y_hex = hex(self.y)[2:].zfill(64)
        return ''.join([self.PREFIX_UNCOMPRESSED, point_x_hex, point_y_hex])


class KeyPair(
        NamedTuple('KeyPair', [
            ('public_key', PublicKey),
            ('private_key', str),
        ])):
    pass


def pbkdf2(password: str, key_size: int) -> str:
    salt = SHA384.new(password.encode('utf-8')).hexdigest()
    salt = SHA384.new(salt.encode('utf-8')).hexdigest()
    assert key_size % 8 == 0
    key = PBKDF2(password, salt, int(key_size / 8), 10000)
    return binascii.hexlify(key).decode('utf-8')


def derive_private_key(mnemonic: str) -> str:
    key = pbkdf2(mnemonic, 256)
    private_key = sha256(key)
    assert len(private_key) == 64
    return private_key


def derive_public_key(private_key: str) -> PublicKey:
    point = FASTECDSA_CURVE.G * int(private_key, 16)

    return PublicKey(point.x, point.y)


def derive_keypair(mnemonic: str) -> KeyPair:
    private_key = derive_private_key(mnemonic)

    return KeyPair(derive_public_key(private_key), private_key)
