import glob
import os

from setuptools import setup


def parse_requirements(filename):
    result = list()
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)

    for line in open(path):
        line = line.strip()

        if not line:
            continue

        if line.startswith('-r'):
            result.extend(parse_requirements(line.split(' ')[1]))
        else:
            result.append(line)

    return result


def find_data_files(base, globs):
    """Find all interesting data files, for setup(data_files=)
    Arguments:
      root:  The directory to search in.
      globs: A list of glob patterns to accept files.
    """

    rv_dirs = [root for root, dirs, files in os.walk(base)]
    rv = []
    for rv_dir in rv_dirs:
        files = []
        for pat in globs:
            files += glob.glob(os.path.join(rv_dir, pat))
        if not files:
            continue
        target = os.path.join('lib', rv_dir)
        rv.append((target, files))

    return rv

setup(
    name='base_client',
    version='0.0.1',
    author='Bitclave',
    license='MIT',
    platforms=['any'],
    description='Bitclave BASE Node client',
    long_description=open('README.rst').read(),
    url='https://github.com/bitclave/base-client-python',
    packages=['base_client'],
    include_package_data=True,
    # package_data={'base_client': ['mypy/base_client/*.pyi']},
    data_files=find_data_files('mypy', ['*.pyi']),
    dependency_links=[  # TODO Deprecated? No alternative?! https://github.com/pypa/pip/issues/4187
        'https://github.com/mfranciszkiewicz/pyelliptic/archive/849f3fc7127c05dbd4c84a3a263517f726700bf2.tar.gz#egg=pyelliptic-1.5.10',
    ],
    install_requires=[
        'fastecdsa==1.6.3',
        'pycryptodome==3.6.0',
        'pyelliptic==1.5.10',
        'python-bitcoinlib==0.10.1',
        'requests==2.18.4',
    ],
    tests_require=[
        'pytest-cache==1.0',
        'pytest-cov==2.5.1',
        'pytest-runner==4.2',
        'pytest==3.1.3',
        'tox==2.9.1',
    ],
    setup_requires=[
        'pytest-runner',
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent', 'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.2',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Intended Audience :: Developers', 'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries :: Python Modules'
    ])
