base-client-python |Build status|
=================================

Bitclave BASE Node client.


Requirements
------------

Python 3.6


Installation
------------

.. code:: sh

    $ pip install --process-dependency-links git+https://github.com/bitclave/base-client-python


Setup
-----

.. |Build status| image:: https://travis-ci.org/.../base-client-python.svg?branch=master
   :target: https://travis-ci.org/.../base-client-python
